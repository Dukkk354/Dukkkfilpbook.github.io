# Flpbook-Page-Slider-Clone-

Real3D Flipbook transforms your documents into ultra realistic 3D flipbooks with page flip animations, lights and shadows. Easy to use and fully customizable. No flash needed, 100% HTML5. No server side conversion, everything is done at runtime, you just set the pdf file url or images. It supports dynamic HTML content on pages, add youtube video, text, image, link, iframe and style it with inline CSS. Pdf flipbook supports internal and external links and text search with keyword highlighting. It comes with multiple view modes : realistic WebGL mode, fast 3D & 2D mode (CSS only) and Swipe mode with horizontal swipe page transitions. You can choose different view mode for mobile and desktop. It is a mature product that offers the best reading experience on all platforms and devices. All future updates are free. Source files and documentation included.

Easy to use
Creating flipbooks is fast and easy, with couple of lines of javascript code. There are many ready to use html examples provided with the plugin.

Create flipbooks from PDF or images
You can create 3D book directly from the PDF file. All links inside the pdf will automatically work inside the flipbook. You can also create flipbook from jpg images.
